package org.humber.student.services;

import org.humber.student.domain.Customer;

public interface CustomerValidationService {
    void validateCustomer(Customer customer);
}
